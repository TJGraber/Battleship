package com.example.tj_battleship;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ResourceBundle;

public class BattleshipController implements Initializable {

    @FXML
    AnchorPane anchorPane;

    @FXML
    Rectangle rect;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


    }
}